
# placeholder bot code
print("Restzona bot")
